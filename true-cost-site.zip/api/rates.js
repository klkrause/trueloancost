import { kv } from '@vercel/kv';
import fallback from '../data/rates-manual.json' assert { type: 'json' };

// GET /api/rates
// Returns the latest cached rate data. Falls back to the static manual
// config (with no mortgage rates) if KV has never been populated yet,
// e.g. right after first deploy before the cron has run once.
export default async function handler(req, res) {
  res.setHeader('Cache-Control', 's-maxage=3600, stale-while-revalidate=86400');

  try {
    const rates = await kv.get('loan-rates');
    if (rates) {
      return res.status(200).json(rates);
    }
  } catch (err) {
    // KV not configured or unreachable — fall through to static fallback
  }

  return res.status(200).json({
    ...fallback,
    mortgage30: null,
    mortgage15: null,
    lastRefreshed: null,
    note: 'Fallback data — daily refresh has not run yet or KV is not connected.',
  });
}
