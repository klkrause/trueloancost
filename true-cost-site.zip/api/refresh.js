import { kv } from '@vercel/kv';
import manual from '../data/rates-manual.json' assert { type: 'json' };

// GET /api/refresh
// Called once a day by Vercel Cron (see vercel.json). Pulls current
// 30-year and 15-year mortgage rates from FRED (Freddie Mac's official
// weekly PMMS survey, published for free by the St. Louis Fed) and
// combines them with the manually-maintained rates for loan types that
// don't have a free public API. Writes the result to Vercel KV so
// /api/rates can serve it instantly without hitting FRED on every request.
export default async function handler(req, res) {
  // Vercel sends this header automatically on cron-triggered requests
  // when CRON_SECRET is set as an environment variable.
  const authHeader = req.headers['authorization'];
  if (process.env.CRON_SECRET && authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const fredKey = process.env.FRED_API_KEY;
  if (!fredKey) {
    return res.status(500).json({ error: 'FRED_API_KEY environment variable is not set' });
  }

  try {
    const [m30, m15] = await Promise.all([
      fetchFredLatest('MORTGAGE30US', fredKey),
      fetchFredLatest('MORTGAGE15US', fredKey),
    ]);

    const rates = {
      mortgage30: { rate: m30.value, source: 'FRED / Freddie Mac PMMS', asOf: m30.date },
      mortgage15: { rate: m15.value, source: 'FRED / Freddie Mac PMMS', asOf: m15.date },
      auto_new: manual.auto_new,
      auto_used: manual.auto_used,
      personal: manual.personal,
      boat: manual.boat,
      student: manual.student,
      lastRefreshed: new Date().toISOString(),
    };

    await kv.set('loan-rates', rates);
    return res.status(200).json({ ok: true, rates });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}

async function fetchFredLatest(seriesId, apiKey) {
  const url = `https://api.stlouisfed.org/fred/series/observations?series_id=${seriesId}&api_key=${apiKey}&file_type=json&sort_order=desc&limit=1`;
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(`FRED request failed for ${seriesId}: ${resp.status}`);
  const data = await resp.json();
  const obs = data.observations && data.observations[0];
  if (!obs) throw new Error(`No observations returned for ${seriesId}`);
  return { value: parseFloat(obs.value), date: obs.date };
}
